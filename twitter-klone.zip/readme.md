# Hva må du gjøre for å se siden?
## For å se siden må du:
1. Åpne mappen med en localhost server, som for eksempel den som er innebygd i VS Code.
2. Åpne `index.html` i nettleseren via serveren.
3. Fjerne alle tingene i localstorage, hvis det finnes noe der fra før av.
4. laste inn siden på nytt.
5. vente i ca. 15 sekunder.
6. logg inn eller registrer en ny bruker.

## Brukere du kan logge inn med:
<!-- brukernavn, passord123 -->
1. Brukernavn: `brukernavn`, Passord: `passord`
2. Brukernavn: `admin`, Passord: `admin`
3. Brukernavn: `test`, Passord: `test`
4. Brukernavn: `elonmusk`, Passord: `teshla`
5. Brukernavn: `billgates`, Passord: `microsoft`
6. Brukernavn: `mark_zuck`, Passord: `metaverse`
7. Brukernavn: `jbezos`, Passord: `smilemazon`
7. Brukernavn: `timcook`, Passord: `crookednook`
